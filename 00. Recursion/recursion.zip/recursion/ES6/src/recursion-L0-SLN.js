﻿

// (1) Write a recursive function to count and log 1 to N
//
function from1ToN(n) {
  if (!n) {
    return 0;
  }

  from1ToN(n-1);
  console.log(n);
}

from1ToN(5);
console.log();









// (2) Write a recursive function to count and log N to 1
//
function fromNTo1(n) {
  if (!n) {
    return 0;
  }

  console.log(n);
  fromNTo1(n-1);
}

fromNTo1(5);
console.log();








// (3) Write a recursive function to count and log X to Y inclusive.  Assume X is always less than Y
//
function fromXtoY(x,y) {
  if (x > y) {
    return 0;
  }

  console.log(x);
  fromXtoY(x+1, y);
}

fromXtoY(5,10);
console.log();








// (4) Write a recursive function to calculate the length of an array
//
function getLength(input) {
  let length = 0;

  function recurse(input) {
    if (!input || !input.length) {
      return 0;
    }

    recurse(input.slice(1));
    length += 1;
  }

  recurse(input);
  return length;
}

console.log(getLength([1,2,3,4,5,6,7,8,9,10])); // => 10
console.log();







// (5) Write a recursive function to calculate the sum of an array
//
function sumArray(input) {
  let sum = 0;

  function recurse(input) {
    if (!input || !input.length) {
      return 0;
    }

    sum += input[0];
    recurse(input.slice(1));
  }

  recurse(input);
  return sum;
}

console.log(sumArray([1,2,3,4])); // => 10
console.log();





// (6) Write a recursive function to calculate the average of the values in an array
//   [23, 17, 23, 42, 8, 2, 73, 101, 83, 92] => 46.4
//
function average(input) {
  let length = 0;
  let sum = 0;

  function recurse(input) {
    if (!input || !input.length) {
      return 0;
    }

    length += 1;
    sum += input[0];
    recurse(input.slice(1));
  }

  recurse(input);
  return sum / length;
}

console.log(average([23, 17, 23, 42, 8, 2, 73, 101, 83, 92]));
console.log();






// (7) Write a recursive function to return the sum of all evens in an array
//
function calculateEvens(input) {
  let sum = 0;

  function recurse(input) {
    if (!input || !input.length) {
      return 0;
    }

    if (input[0] % 2 == 0) {
      sum += input[0];
    }

    recurse(input.slice(1));
  }

  recurse(input);
  return sum;
}


function sumOfEvens(input, n) {
  if (!n) {
    return 0;
  }
  return input[n] % 2 == 0 ? input[n] + sumOfEvens(input, n-1) : 0 + sumOfEvens(input, n-1);
}

console.log(calculateEvens([1,2,3,4,5,6,7,8])); // => 20
console.log();






// (8) Write a recursive function to compute the number of digits in an integer
//
function numberOfDigits(n) {
  if (n < 10) {
    return 1;
  }
  else {
    return 1 + numberOfDigits(n / 10);
  }
}

console.log(numberOfDigits(13028)); // => 5
console.log();





// (9) Write a recursive function to return whether the integer contains the number K
//
function nContainsK(n, k) {
  n = ~~n; // Convert floats to whole numbers
  k = ~~k; // Convert floats to whole numbers

  if (n <= 9) {
    return n == k;
  }
  else if (n % 10 == k) {
    return true;
  }
  else {
    return nContainsK( n / 10, k);
  }
}

console.log(nContainsK(132520, 5));
console.log();





// (10) Write a recursive function to calculate the power of a number (exponent, number)
//
function power(a, n) {
  if (n === 0) {
    return 1.0;
  }
  else {
    if (n > 0) {
      return a * power(a, n-1);
    }
  }
}

console.log(power(2.0, 4));