
class L0 {
  // (1) Write a recursive function to count and log 1 to N
  //
  from1ToN(n) {
    if (!n) {
      return 0;
    }

    from1ToN(n-1);
    console.log(n);
  }




  // (2) Write a recursive function to count and log N to 1
  //
  fromNTo1(n) {

  }




  // (3) Write a recursive function to count and log X to Y inclusive.  Assume X is always less than Y
  //
  fromXtoY(x, y) {

  }




  // (4) Write a recursive function to calculate the length of an array
  //
  getLength(input) {

  }




  // (5) Write a recursive function to calculate the sum of an array
  //
  sumArray(input) {

  }




  // (6) Write a recursive function to calculate the average of the values in an array
  //   [23, 17, 23, 42, 8, 2, 73, 101, 83, 92] => 46.4
  //
  average(input) {

  }




  // (7) Write a recursive function to return the sum of all evens in an array
  //
  calculateEvens(input) {

  }




  // (8) Write a recursive function to compute the number of digits in an integer
  //
  numberOfDigits(n) {

  }




  // (9) Write a recursive function to return whether the integer contains the number K
  //
  nContainsK(n, k) {

  }




  // (10) Write a recursive function to calculate the power of a number (exponent, number)
  //
  power(a, n) {

  }
}