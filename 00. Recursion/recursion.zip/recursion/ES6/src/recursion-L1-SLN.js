


// (1) Write a recursive function to print the digits of an integer in reverse order.  Do not convert to string first
//     2234295 should return 5924322
//
function reverseInt(n) {
  let result = "";

  function recurse(n) {
    n = ~~n;

    result += n % 10;
    if (n <= 9) {
      return n;
    }
    else {
      recurse(n / 10);
    }
  }

  recurse(n);
  return parseInt(result);
}

console.log(reverseInt(2234295));




// (2) Write a recursive function to convert an int to a binary string
//   7 => 111
//   16 => 10000
//   10 => 1010
//   37 => 100101
//
function intToBinary(n) {
  let result = "";


  function recurse(n) {
    n = ~~n;

    if (!n) {
      return "0";
    }

    result = ((n & 0x01) ? "1" : "0") + result;
    recurse(n >> 1);
  }

  recurse(n);
  return result;
}

console.log(intToBinary(37));




// (3) Write a recursive function to print a postive integer with commas
//
//   1940 => 1,940
//   2930194 => 2,930,194
//
function intWithCommas(n) {
  let result = "";

  function recurse(n) {
    n = ~~n;

    if (n < 1000) {
      result += n;
    }
    else {
      recurse(n / 1000);
      result += ",";

      if ((n % 1000) < 10) {
        result += "00";
        result += (n % 1000);
      }
      else if ((n % 1000) < 100) {
        result += "0";
        result += (n % 1000);
      }
      else {
        result += (n % 1000);
      }
    }
  }

  recurse(n);
  return result;
}

console.log(intWithCommas(34223));



// (4) Write a recursive function that prints the letter "X" once if the number is zero.  Otherwise, it will
//      make a recursive call twice with (n-1).
//
//   Try it with the following inputs and make a note how many X's get printed:
//
//     2
//     3
//     4
//
function logXXs(n) {
  if (n == 0) {
    console.log("X");
  }
  else {
    logXXs(n-1);
    logXXs(n-1);
  }
}

logXXs(2);



// (5) Write a recursive function to print a line with the number of X's indicated by n
//
//   n=3   => XXX
//   n=5   => XXXXX
//   etc.
//
function logLineWithNXs(n) {
  let result = "";

  function recurse(n) {
    if (n == 0) {
      return "X";
    }

    result += "X";
    recurse(n-1);
  }

  recurse(n);
  console.log(result);
}

logLineWithNXs(3);



// (6) Write a recursive function to print a triangle the number of lines indicated by n
//
//   1 =>    X
//
//   3 =>    X
//           XX
//           XXX
//
//   5 =>    X
//           XX
//           XXX
//           XXXX
//           XXXXX
//
//   Etc.
//
function logTriangle(n) {
  if (n == 1) {
    console.log("X");
  }
  else {
    logTriangle(n-1);
    logLineWithNXs(n);
  }
}

logTriangle(5);



// (7) Write a recursive function that prints a triangle upside down
//
//   n=3   => XXX
//            XX
//            X
//
//   Etc.
//
function logTriangleUpsideDown(n) {
  if (n == 1) {
    console.log("X");
  }
  else {
    logLineWithNXs(n);
    logTriangleUpsideDown(n-1);
  }
}

logTriangleUpsideDown(5);



// (8) Write a recursive function to reverse an array in-place
//
function reverseArray(input) {
  let mid = Math.floor(input.length / 2);
  let n = 0;

  function recurse(n) {
    if (n == mid) {
      return;
    }

    [input[n], input[input.length-1-n]] = [input[input.length-1-n], input[n]];
    recurse(n+1);
  }

  recurse(n);
  return input;
}

console.log(reverseArray([1,2,3,4,5,6,7]));



// (9) Write a recursive function to compare two arrays and determine if they are equal
//
function equalArray(a, b, n1, n2) {
  if (n1 != n2) {
    return false;
  }
  else if (n1 == 0) {
    return true;
  }
  else if (a[n1-1] != b[n2-1]) {
    return false;
  }
  else {
    return equalArray(a, b, n1-1, n2-1);
  }
}

console.log(equalArray([1,2,3,4,5], [1,2,5,4,5], 5, 5));



// (10) Write a recursive function that will return the position of the largest element in a
//       non empy array
//
function maxIndexInArray(input, n) {
  if (n == 1) {
    return 0;
  }
  else {
    let max = maxIndexInArray(input, n-1);
    if (input[max] > input[n-1]) {
      return max;
    }
    else {
      return n-1;
    }
  }
}

console.log(maxIndexInArray([1,2,5,2,5,2,19,5,2], 9));



// (11) Write a recursive function to determine if an array is sorted (in increasing order)
//
//    [1,2,3,4,5,6] is sorted
//    [1,2,3,4,5,1] is not sorted
//
// Return true/false
//
function isArraySorted(input, n) {
  if (n <= 1) {
    return true;
  }
  else if (input[n-1] >= input[n-2]) {
    return isArraySorted(input, n-1);
  }
  else {
    return false;
  }
}

console.log(isArraySorted([1,2,3,4,5,6], 6));



// (12) Write a recursive function to fill an pre-allocated array with increasing numbers
//       from 1 to n
//
function fillArrayIncreasing(input, n) {
  if (n==1) {
    input[0] = 1;
  }
  else {
    fillArrayIncreasing(input, n-1);
    input[n-1] = n;
    return input;
  }
}

console.log(fillArrayIncreasing(new Array(5), 5));



// (13) Write a recursive funftion to determine if an array is palindrome
//
function isPalindrome(input) {
  let first = 0;
  let last = input.length-1;

  function recurse(input, first, last) {
    if (first >= last) {
      return true;
    }
    else if (input[first] != input[last]) {
      return false;
    }
    else {
      return recurse(input, first + 1, last - 1);
    }
  }

  return recurse(input, first, last);
}

console.log(isPalindrome([1,2,3,4,3,2,1]));



// (14) Write a recursive function to flatten an array
//
function flattenArray(input) {
  if (typeof input === "number") {
    return [input];
  }
  else if (!input.length) {
    return [];
  }
  else {
    return flattenArray(input[0]).concat(flattenArray(input.slice(1)));
  }
}

console.log(flattenArray([1,2,[3,4,[5,6,7]]]));

