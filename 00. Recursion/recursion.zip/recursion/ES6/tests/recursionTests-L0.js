

describe("Linked Lists - Part I | Finding Nodes & Linkage", () => {
  let sinon = require("sinon");
  let code;

  before(() => {
    code = new L1();
  });

  beforeEach(() => {
    sinon.stub(console, "log").returns(void 0);
    sinon.stub(console, "error").returns(void 0);
  });

  afterEach(() => {
    console.log.restore();
    console.error.restore();
  });

  it("Count from 1 to N", () => {
    code.from1ToN(5);

    expect(consol.log.getCall(0).args[0]).to.equal("1");
  });
});